# Changelog
All notable changes to this project will be documented in this file.

## [1.0.0] - 2025-06-13
- Initial release of Responsive Element Manager plugin.

### Added
- Visual editor in real-time
- Multi-breakpoint responsive system
- Complete font controls
- Layout management
- Flexible scoping options
