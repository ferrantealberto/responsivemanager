<?php
function rem_admin_page_template() {
    // Admin page template content
}
