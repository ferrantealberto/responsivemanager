<?php
/**
 * Index file for directory protection
 * 
 * This file prevents directory listing and unauthorized access
 * to the Responsive Element Manager plugin directory.
 */

// Silence is golden - prevents directory listing
exit;