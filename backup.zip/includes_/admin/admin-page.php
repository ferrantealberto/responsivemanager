<?php
// Admin page content
?>
<div class="wrap">
    <h1>Responsive Elements</h1>
    <!-- Page content here -->
</div>
