<?php
// Admin help content
?>
<div class="wrap">
    <h1>Responsive Elements Help</h1>
    <!-- Help content here -->
</div>
