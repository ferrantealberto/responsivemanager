<?php
// Admin rules list content
?>
<div class="wrap">
    <h1>Responsive Elements Rules</h1>
    <!-- Rules list here -->
</div>
