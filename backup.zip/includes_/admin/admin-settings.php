<?php
// Admin settings content
?>
<div class="wrap">
    <h1>Responsive Elements Settings</h1>
    <!-- Settings form here -->
</div>
